<?php

namespace Park;

interface Navigable {
    public function addParking( Parking $parking):void;
}